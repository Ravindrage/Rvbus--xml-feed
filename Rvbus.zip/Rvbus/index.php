<?php 
include "connection.php"; 
include "index2.php";
?>

<?php


$sql = "SELECT * FROM tbl_xmldata GROUP BY class limit 7";
$result = $conn->query($sql);

?>


<?php

$html = file_get_html('http://www.rvcorral.com/');

// Find all article blocks
foreach($html->find('div.et_pb_slides') as $article) {
    $item['title']     = $article->find('div.title', 0)->plaintext;
    $item['intro']    = $article->find('div.intro', 0)->plaintext;
    $item['details'] = $article->find('div.details', 0)->plaintext;
    $articles[] = $item;
}

print_r($articles); 


?>


<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="www.eugenervs.com">
    <meta name="author" content="">
    <title>EUGENE RV'S Selling Class A Diesel & Gas, Class C, Fifth Wheels, Toyhaulers and travel trailers. </title>
	
	<link rel="stylesheet" href="css/animations.css" type="text/css">	
	<link href='http://fonts.googleapis.com/css?family=Lato&subset=latin,latin-ext' rel='stylesheet' type='text/css'>			
	
	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body class="homepage">
	    <header id="header" >
        <div class="top-bar" style="background-color:#CCCCCC;" >
		 
            <div class="container" >
                <div class="row" >
                    <div class="col-sm-6 col-xs-4">
                        <div class="top-number title1">Road, Glasgow D04 89GR</div>
                    </div>
                    <div class="col-sm-6 col-xs-8">
                       <div class="social">
                            <ul class="social-share title2">
                              Call us: (800) 2345-6789
                            </ul>
                            </div>
                    </div>
                </div>
            </div><!--/.container-->
        </div><!--/.top-bar-->

        <nav class="navbar navbar-inverse" role="banner">
		   <!--<div style="width:50px; font-size:10px; float:left; color:#FFFFFF;">Email : sales@eugenervs.com
          Phone : 541-514-1332 </div>-->
            <div class="container">
                <div class="navbar-header" style="background-color:#f50606; padding:25px 6px; margin-top:5px;">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">EUGENE RV <!--<img src="images/logo.png" alt="logo">--></a>
                </div>
				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
					  <li><div  class="notification">To enable scroll: Move slider left or right</div></li>
					  <?php   
							if ($result->num_rows > 0) {							
							$incre_num = 1;
							while($row = $result->fetch_assoc()) {
														
							if($incre_num==1)
							{
							$first = '<li style="text-align:center;"><a href="category.php?class='.$row['class'].'">'.$row['class'].'
							<p><img src="images/menu/'.$incre_num.'.png" style="height:60px; width:105px; border-radius:10px;"/></p></a> 
		<!--<p style="height:10px;color:#fff;margin-top:-15px;"><a href="category.php?class='.$row['class'].'&used=1" style="font-size:10px; padding:0px;margin-top:-5px;color:#fff;">New</a></p>
	<p style="height:10px;color:#fff;margin-top:-10px;"><a href="category.php?class='.$row['class'].'&used=0" style="font-size:10px; padding:0px; margin-top:-5px;color:#fff;">Used</a></p>--></li>';         $incre_num++;
	                         }
							 else
							 {
							 echo '<li style="text-align:center;"><a href="category.php?class='.$row['class'].'">'.$row['class'].'
							<p><img src="images/menu/'.$incre_num.'.png" style="height:60px; width:105px; border-radius:10px;"/></p></a> 
		<!--<p style="height:10px;color:#fff;margin-top:-15px;"><a href="category.php?class='.$row['class'].'&used=1" style="font-size:10px; padding:0px;margin-top:-5px;color:#fff;">New</a></p>
	<p style="height:10px;color:#fff;margin-top:-10px;"><a href="category.php?class='.$row['class'].'&used=0" style="font-size:10px; padding:0px; margin-top:-5px;color:#fff;">Used</a></p>--></li>';         $incre_num++;
	                            //echo $row['date'];
							}
							
							if($incre_num==5){	echo $first; }
	
	
							}
							} else {
							echo "0 results";
							}
					   ?>
                       
                       
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
		
    </header><!--/header-->

<section id="main-slider" class="no-margin">
        <div class="carousel slide" data-ride="carousel" >
            <ol class="carousel-indicators">
                <li data-target="#main-slider" data-slide-to="0" class="active"></li>
                <li data-target="#main-slider" data-slide-to="1"></li>
                <li data-target="#main-slider" data-slide-to="2"></li>
            </ol>
            <div class="carousel-inner">

                <div class="item active" style="background-image: url(images/slider/0111.jpg)">
                    <div class="container">
                        <div class="row slide-margin">
                            <div class="col-sm-61">
                                <div class="carousel-content" style="text-align:center;">
                                    <h1 class="animation animated-item-1">BUY NEW SHOCKWAVES BELOW NADA PRICES!!</h1>
                                    <h2 class="animation animated-item-2">NF-707 2015 SHOCKWAVE 35RGDX TOYHAULER WAS $69,069, NOW $48,995</h2>
                                 </div>
                            </div>
                            </div>
                    </div>
                </div>
                <!--/.item-->

                <div class="item" style="background-image: url(images/slider/DSC06734.jpg)">
                    <div class="container">
                        <div class="row slide-margin">
                            <div class="col-sm-61">
                                <div class="carousel-content" style="text-align:center;">
                                    <h1 class="animation animated-item-1">NEW 45′ ALLEGRO BY TIFFIN BUS BELOW NADA PRICES!!
NA-898 ALLEGRO BUS 45OP 600HP ENGINE!! WAS $522,592 NOW $399,995</h1>
                                    <h2 class="animation animated-item-2">NA-900 ALLEGRO BUS 45UP WAS $441,042 NOW</h2>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!--/.item-->

                <div class="item" style="background-image: url(images/slider/033.jpg)">
                    <div class="container">
                        <div class="row slide-margin">
                            <div class="col-sm-61">
                                <div class="carousel-content" style="text-align:center;">
                                    <h1 class="animation animated-item-1">NEW WINNEBAGO CLASS C MOTORHOMES BELOW NADA PRICES!!</h1>
                                    <h2 class="animation animated-item-2">NC-459 ’15 MINNIE WINNIE 27Q WAS $85,752 NOW $65,995
NC-462 ’15 MINNIE WINNIE 31H WAS $93,856 NOW $74,995</h2>
                              </div>
                            </div>
                      </div>
                    </div>
                </div>
                <!--/.item-->
            </div><!--/.carousel-inner-->
        </div><!--/.carousel-->
     <a class="prev hidden-xs" href="#main-slider" data-slide="prev">
         <i class="fa fa-chevron-left"></i>     </a>
     <a class="next hidden-xs" href="#main-slider" data-slide="next">
         <i class="fa fa-chevron-right"></i>     </a>  </section>
   <!--/#main-slider-->
   
   
    <section id="feature" >
        <div class="container">
					<div class="row">
					<div style="text-align:center;">  Email : sales@eugenervs.com &nbsp;&nbsp;
                        Phone : 541-514-1332 </div>
					</div>
					</div>
					</div>
	
    <section id="feature" >
        <div class="container">
					<div class="row"> <div style="margin:5px 15px; text-align:center;"> Our Rv Classes</div>     <div class="image-zoom-container">
					     <?php 						 
						    $sql = "SELECT * FROM tbl_xmldata GROUP BY class limit 6";
                            $result = $conn->query($sql);
							if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) {
						 ?>					   
						<!--/.zoom-container-->
						<div class="zoom-container">
						<a href="category.php?class=<?php echo $row['class']; ?>">
						<span class="zoom-caption">
						<h3><?php echo $row['brand']; ?>&nbsp;<?php echo $row['manufacturer']; ?>&nbsp;<?php echo $row['class']; ?> </h3>
						</span>
						<?php       
						
						 if($row['Photo1']=="")
						 {   $photo = $photo ;   }else { $photo = $row['Photo1'];}
						  
						
						?>								
						<img src="<?php echo $photo ; ?>" />
						</a>
						</div>
							<?php
								}
								} else {
								echo "0 results";
								}							
							?>
							</div>
						
					</div><!--/.row-->    
        </div><!--/.container-->
    </section><!--/#feature-->

    <!--/#recent-works-->
	

    <section >
	   <div class="container animatedParent"> <div style ="text-align:center;"> Other Models </div>
	   <p>&nbsp;</p>
            <div class="row">
			    
				
				
				 <?php 		 
						    $sql = "SELECT * FROM tbl_xmldata GROUP BY model limit 9 ";
								$result = $conn->query($sql); $i=1;
								if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) {
							
							 if($row['Photo1']=="")
						     {  $photo = $photo;   }else { $photo = $row['Photo1'];}
						 
						     if($i==3)
							 {  $photo = $photo;   } $i++;
						  
				 ?>	
                <a href="product.php?autoid=<?php echo $row['autoid']; ?>">
				<ul class="demo-3">
				<li>
				<figure>
				<img src="<?php echo $photo; ?>" alt=""/>
				<figcaption>
				<h2><?php echo $row['brand']; ?></h2>
				<p><?php echo $row['description']; ?></p>
				<p>&nbsp;</p>
				<p>$<?php echo $row['price1']; ?></p>
				</figcaption>
				</figure>
				</li>
				</ul>
				</a>
				<?php } }?>

									
		</div>
		</div><!--/.container-->
    </section><!--/#services-->

    <!--/#middle-->

    <!--/#content-->

    <!--/#partner-->

    <!--/#conatcat-info-->

    <!--/#bottom-->
	
	<div id="light" class="white_content">
	<a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'" style="font-weight:bold; float:right; margin-top:-10px;">X</a>
		 <form name="" id="" action="contactus.php" method="post" enctype="multipart/form-data">
		 <table align="center">
		 <tr><td colspan="2"><div style="text-align:center;">  Email : sales@eugenervs.com </br>
                        Phone : <a href="tel:541-514-1332">541-514-1332 </a> <br/></div>
					</div></td></tr>
					<tr><td>&nbsp;</td></tr>
		 <tr><td>Name *</td><td><input type="text" name="name" id="name" class="contact-form1" ></td></tr>
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>Email *</td><td><input type="text" name="email" id="email" class="contact-form1"></td></tr>
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>Phone * </td><td><input type="text" name="phoneno" id="phoneno" class="contact-form1"></td></tr> 
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>Comments *</td><td><textarea name="comment" id="comment" class="contact-form2"></textarea></td></tr>
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>&nbsp;</td></tr>
		 <tr><td colspan="10" style="text-align:right;"><input type="submit" name="submit" style="width:200px; height:30px;" id="submit" value="Submit"></td><td></td></tr>
		 
		 </table>
		</form>
		
		</div>
		<div id="fade" class="black_overlay"></div>
		

    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2016 & Beyond <a target="_blank" href="http://eugenervs.com/" title="EUGENE RV'S Selling Class A Diesel & Gas, Class C, Fifth Wheels, Toyhaulers and travel trailers">EugeneRvs.com</a>. All Rights Reserved.
                </div>
                <div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href="/index.php">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Faq</a></li>
                        <li><a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='block';document.getElementById('fade').style.display='block'">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->
	
    <script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>                
	<script type="text/javascript">
            var widgetOnExit = 'no';
            var widgetDelay = 5;
            var widgetOnReload = 'yes';
            var widgetChatID = '11063';
            var widgetLocation = '//chatanywherenow.com/';
            (function() {
            var cw = document.createElement('script');
                cw.type = 'text/javascript';
                cw.async = true;
                cw.src = widgetLocation + 'assets/chat/widget.js?v=ipv5';
                var s = document.getElementsByTagName('script')[0];
                s.parentNode.insertBefore(cw, s);
            })();
        </script>
     
</body>
</html>