<?php //$con = mysql_connect("localhost","root","");

//if (!$con)
//{ die('Could not connect: ' . mysql_error()); }

//mysql_select_db("vertrigo", $con);



//$servername = "localhost";
//$username = "root";
//$password = "";
//$dbname = "vertrigo";


$servername = "mysql5.000webhost.com";
$username = "a8139674_ravin";
$password = "ravindra098";
$dbname = "a8139674_ravin";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
} 







?>