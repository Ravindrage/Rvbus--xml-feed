<?php include "connection.php"; ?>




<?php 
        // print_r($_REQUEST);

	//Email information
		

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="www.eugenervs.com">
    <meta name="author" content="">
	
	 <?php    
                 if(isset($_REQUEST['autoid']) and !empty($_REQUEST['autoid']))
					{
					$sql = "SELECT * FROM tbl_xmldata where autoid = '".$_REQUEST['autoid']."'";
					$result = $conn->query($sql);
					}
     				
					if ($result->num_rows > 0) { 
					while($row = $result->fetch_assoc()) {
					$brand = $row['brand'];
					}
					}
	?>
							
    <title><?php echo $brand ?> | EUGENE RV</title>
	
	<link rel="stylesheet" href="css/animations.css" type="text/css">	
	<link href='http://fonts.googleapis.com/css?family=Lato&subset=latin,latin-ext' rel='stylesheet' type='text/css'>			
	

	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
    <!--///////////////////////////////////////////////////////////////////////////////////////////////////
    //
    //		Scripts
    //
    ///////////////////////////////////////////////////////////////////////////////////////////////////-->     
	
	<link href="dist/css/lightgallery.css" rel="stylesheet">
        <style type="text/css">
            
			.demo-gallery > ul {
              margin-bottom: 0;
            }
            .demo-gallery > ul > li {
                float: left;
                margin-bottom: 15px;
                width: 200px;
            }
            .demo-gallery > ul > li a {
              border: 3px solid #FFF;
              border-radius: 3px;
              display: block;
              overflow: hidden;
              position: relative;
              float: left;
            }
            .demo-gallery > ul > li a > img {
              -webkit-transition: -webkit-transform 0.15s ease 0s;
              -moz-transition: -moz-transform 0.15s ease 0s;
              -o-transition: -o-transform 0.15s ease 0s;
              transition: transform 0.15s ease 0s;
              -webkit-transform: scale3d(1, 1, 1);
              transform: scale3d(1, 1, 1);
              height: 100%;
              width: 100%;
            }
            .demo-gallery > ul > li a:hover > img {
              -webkit-transform: scale3d(1.1, 1.1, 1.1);
              transform: scale3d(1.1, 1.1, 1.1);
            }
            .demo-gallery > ul > li a:hover .demo-gallery-poster > img {
              opacity: 1;
            }
            .demo-gallery > ul > li a .demo-gallery-poster {
              background-color: rgba(0, 0, 0, 0.1);
              bottom: 0;
              left: 0;
              position: absolute;
              right: 0;
              top: 0;
              -webkit-transition: background-color 0.15s ease 0s;
              -o-transition: background-color 0.15s ease 0s;
              transition: background-color 0.15s ease 0s;
            }
            .demo-gallery > ul > li a .demo-gallery-poster > img {
              left: 50%;
              margin-left: -10px;
              margin-top: -10px;
              opacity: 0;
              position: absolute;
              top: 50%;
              -webkit-transition: opacity 0.3s ease 0s;
              -o-transition: opacity 0.3s ease 0s;
              transition: opacity 0.3s ease 0s;
            }
            .demo-gallery > ul > li a:hover .demo-gallery-poster {
              background-color: rgba(0, 0, 0, 0.5);
            }
            .demo-gallery .justified-gallery > a > img {
              -webkit-transition: -webkit-transform 0.15s ease 0s;
              -moz-transition: -moz-transform 0.15s ease 0s;
              -o-transition: -o-transform 0.15s ease 0s;
              transition: transform 0.15s ease 0s;
              -webkit-transform: scale3d(1, 1, 1);
              transform: scale3d(1, 1, 1);
              height: 100%;
              width: 100%;
            }
            .demo-gallery .justified-gallery > a:hover > img {
              -webkit-transform: scale3d(1.1, 1.1, 1.1);
              transform: scale3d(1.1, 1.1, 1.1);
            }
            .demo-gallery .justified-gallery > a:hover .demo-gallery-poster > img {
              opacity: 1;
            }
            .demo-gallery .justified-gallery > a .demo-gallery-poster {
              background-color: rgba(0, 0, 0, 0.1);
              bottom: 0;
              left: 0;
              position: absolute;
              right: 0;
              top: 0;
              -webkit-transition: background-color 0.15s ease 0s;
              -o-transition: background-color 0.15s ease 0s;
              transition: background-color 0.15s ease 0s;
            }
            .demo-gallery .justified-gallery > a .demo-gallery-poster > img {
              left: 50%;
              margin-left: -10px;
              margin-top: -10px;
              opacity: 0;
              position: absolute;
              top: 50%;
              -webkit-transition: opacity 0.3s ease 0s;
              -o-transition: opacity 0.3s ease 0s;
              transition: opacity 0.3s ease 0s;
            }
            .demo-gallery .justified-gallery > a:hover .demo-gallery-poster {
              background-color: rgba(0, 0, 0, 0.5);
            }
            .demo-gallery .video .demo-gallery-poster img {
              height: 48px;
              margin-left: -24px;
              margin-top: -24px;
              opacity: 0.8;
              width: 48px;
            }
            .demo-gallery.dark > ul > li a {
              border: 3px solid #04070a;
            }
            .home .demo-gallery {
              padding-bottom: 80px;
            }
        </style>
		
		 <style>
   
</style>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.2/jquery.min.js"></script>
	
	
</head><!--/head-->

<body class="homepage">
	    <header id="header" >
        <div class="top-bar" style="background-color:#CCCCCC;" >
            <div class="container" >
                <div class="row" >
                    <div class="col-sm-6 col-xs-4">
                        <div class="top-number title1">Road, Glasgow D04 89GR</div>
                    </div>
                    <div class="col-sm-6 col-xs-8">
                       <div class="social">
                            <ul class="social-share title2">
                              Call us: (800) 2345-6789
                            </ul>
                            </div>
                    </div>
                </div>
            </div><!--/.container-->
        </div><!--/.top-bar-->
		
		
	

        <nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header" style="background-color:#f50606; padding:25px 6px;margin-top:5px;">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">EUGENE RV <!--<img src="images/logo.png" alt="logo">--></a>
                </div>
				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
					    <?php   
						
						    $sql = "SELECT * FROM tbl_xmldata GROUP BY class limit 7";
                            $result = $conn->query($sql);
						
							if ($result->num_rows > 0) {							
							$incre_num = 1;
							while($row = $result->fetch_assoc()) {
														
							if($incre_num==1)
							{
							$first = '<li style="text-align:center;"><a href="category.php?class='.$row['class'].'">'.$row['class'].'
							<p><img src="images/menu/'.$incre_num.'.png" style="height:60px; width:105px; border-radius:10px;"/></p></a> 
		<!--<p style="height:10px;color:#fff;margin-top:-15px;"><a href="category.php?class='.$row['class'].'&used=1" style="font-size:10px; padding:0px;margin-top:-5px;color:#fff;">New</a></p>
	<p style="height:10px;color:#fff;margin-top:-10px;"><a href="category.php?class='.$row['class'].'&used=0" style="font-size:10px; padding:0px; margin-top:-5px;color:#fff;">Used</a></p>--></li>';         $incre_num++;
	                         }
							 else
							 {
							 echo '<li style="text-align:center;"><a href="category.php?class='.$row['class'].'">'.$row['class'].'
							<p><img src="images/menu/'.$incre_num.'.png" style="height:60px; width:105px; border-radius:10px;"/></p></a> 
		<!--<p style="height:10px;color:#fff;margin-top:-15px;"><a href="category.php?class='.$row['class'].'&used=1" style="font-size:10px; padding:0px;margin-top:-5px;color:#fff;">New</a></p>
	<p style="height:10px;color:#fff;margin-top:-10px;"><a href="category.php?class='.$row['class'].'&used=0" style="font-size:10px; padding:0px; margin-top:-5px;color:#fff;">Used</a></p>--></li>';         $incre_num++;
							}
							
							if($incre_num==5){	echo $first; }
	
	
							}
							} else {
							echo "0 results";
							}
					   ?>
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
		
    </header><!--/header-->
	
	
	<?php
       if(isset($_REQUEST['autoid']) and !empty($_REQUEST['autoid']))
					{
					$sql = "SELECT * FROM tbl_xmldata where autoid = '".$_REQUEST['autoid']."'";
					$result = $conn->query($sql);
					}
     				
					if ($result->num_rows > 0) { 
					while($row = $result->fetch_assoc()) {
?>
	
	<section id="blog" class="container">
        <div class="center">
            <h2> <?php echo $row['brand'];  echo '&nbsp;';  	echo $model = $row['model']; ?> </h2>
            <p class="lead"></p>
        </div>


        <div class="blog">
            <div class="row">
                 <div class="col-md-8">
                    <div class="blog-item">
                        <div class="row">
                                                           
                            <div class="col-xs-12 col-sm-10 blog-content">
							<a href="#"><img src="<?php echo $row['Photo1']; ?>"></a>
							
							
		<div class="demo-gallery">
            <ul id="lightgallery" class="list-unstyled row">
                <li class="col-xs-6 col-sm-4 col-md-3" data-responsive="<?php echo $row['Photo2']; ?> 375, <?php echo $row['Photo2']; ?> 480, <?php echo $row['Photo2']; ?> 800" data-src="<?php echo $row['Photo2']; ?>" data-sub-html="">
                    <a href="">  <img class="img-responsive" src="<?php echo $row['Photo2']; ?>">       </a>
                </li>
                <li class="col-xs-6 col-sm-4 col-md-3" data-responsive="<?php echo $row['Photo3']; ?> 375, <?php echo $row['Photo3']; ?> 480, <?php echo $row['Photo3']; ?> 800" data-src="<?php echo $row['Photo3']; ?>" data-sub-html="">
                    <a href=""><img class="img-responsive" src="<?php echo $row['Photo3']; ?>"> </a>
                </li>
                <li class="col-xs-6 col-sm-4 col-md-3" data-responsive="<?php echo $row['Photo4']; ?> 375, <?php echo $row['Photo4']; ?> 480, <?php echo $row['Photo4']; ?> 800" data-src="<?php echo $row['Photo4']; ?>" data-sub-html="">
                    <a href="">  <img class="img-responsive" src="<?php echo $row['Photo4']; ?>">   </a>
                </li>
                <li class="col-xs-6 col-sm-4 col-md-3" data-responsive="<?php echo $row['Photo5']; ?> 375, <?php echo $row['Photo5']; ?> 480, <?php echo $row['Photo5']; ?> 800" data-src="<?php echo $row['Photo5']; ?>" data-sub-html="">
                    <a href="">  <img class="img-responsive" src="<?php echo $row['Photo5']; ?>">  </a>
                </li>
				<li class="col-xs-6 col-sm-4 col-md-3" data-responsive="<?php echo $row['Photo6']; ?> 375, <?php echo $row['Photo6']; ?> 480, <?php echo $row['Photo6']; ?> 800" data-src="<?php echo $row['Photo6']; ?>" data-sub-html="">
                    <a href="">  <img class="img-responsive" src="<?php echo $row['Photo6']; ?>">   </a>
                </li>
				<li class="col-xs-6 col-sm-4 col-md-3" data-responsive="<?php echo $row['Photo7']; ?> 375, <?php echo $row['Photo7']; ?> 480, <?php echo $row['Photo7']; ?> 800" data-src="<?php echo $row['Photo7']; ?>" data-sub-html="">
                    <a href=""> <img class="img-responsive" src="<?php echo $row['Photo7']; ?>">  </a>
                </li>
				<li class="col-xs-6 col-sm-4 col-md-3" data-responsive="<?php echo $row['Photo8']; ?> 375, <?php echo $row['Photo8']; ?> 480, <?php echo $row['Photo8']; ?> 800" data-src="<?php echo $row['Photo8']; ?>" data-sub-html="">
                    <a href=""><img class="img-responsive" src="<?php echo $row['Photo8']; ?>">     </a>
                </li>
				<li class="col-xs-6 col-sm-4 col-md-3" data-responsive="<?php echo $row['Photo9']; ?> 375, <?php echo $row['Photo9']; ?> 480, <?php echo $row['Photo9']; ?> 800" data-src="<?php echo $row['Photo9']; ?>" data-sub-html="">
                    <a href="">  <img class="img-responsive" src="<?php echo $row['Photo9']; ?>">     </a>
                </li>
				<li class="col-xs-6 col-sm-4 col-md-3" data-responsive="<?php echo $row['Photo10']; ?> 375, <?php echo $row['Photo10']; ?> 480, <?php echo $row['Photo10']; ?> 800" data-src="<?php echo $row['Photo10']; ?>" data-sub-html="">
                    <a href="">  <img class="img-responsive" src="<?php echo $row['Photo10']; ?>">     </a>
                </li>
				<li class="col-xs-6 col-sm-4 col-md-3" data-responsive="<?php echo $row['Photo11']; ?> 375, <?php echo $row['Photo11']; ?> 480, <?php echo $row['Photo11']; ?> 800" data-src="<?php echo $row['Photo11']; ?>" data-sub-html="">
                    <a href="">  <img class="img-responsive" src="<?php echo $row['Photo11']; ?>">     </a>
                </li>
				<li class="col-xs-6 col-sm-4 col-md-3" data-responsive="<?php echo $row['Photo12']; ?> 375, <?php echo $row['Photo12']; ?> 480, <?php echo $row['Photo12']; ?> 800" data-src="<?php echo $row['Photo12']; ?>" data-sub-html="">
                    <a href="">  <img class="img-responsive" src="<?php echo $row['Photo12']; ?>">     </a>
                </li>
				
            </ul>
        </div>
                                 
                                
                            </div>
                        </div>    
                    </div><!--/.blog-item-->
                </div><!--/.col-md-8-->

                <aside class="col-md-4">
                    <div class="widget search">
                       <!-- <form role="form">
                                <input type="text" class="form-control search_box" autocomplete="off" placeholder="Search Here">
                        </form>-->
                    </div><!--/.search-->
    				
    				<div class="widget categories">
                         <div class="row">
                            <div class="col-sm-12">
                                <div class="single_comments">
                                   <p> Stock No. :<?php echo $row['stockno']; ?> </p>								                                    
                                </div>
								<div class="single_comments"><p>Brand :<?php echo $row['brand']; ?></p> </div>
                                <div class="single_comments">
                                    <p>Manufacturer:<?php echo $row['manufacturer']; ?> </p>                                    
                                </div>
                                <div class="single_comments">
                                    <p>Model :<?php echo $row['model']; ?> </p>                                   
                                </div>
                                 <div class="single_comments">
                                    <p>Length :<?php echo $row['length']; ?> </p>                                   
                                </div>
								 <div class="single_comments">
                                    <p>FuelType : <?php echo $row['fueltype']; ?> </p>                                   
                                </div>
								 <div class="single_comments">
                                    <p>Class :<?php echo $row['class']; ?> </p>                                   
                                </div>
								 <div class="single_comments">
                                    <p>Year : <?php echo $row['year']; ?> </p>                                   
                                </div>
								<div class="single_comments">
                                    <p>Description : <?php  echo str_replace("1-800-967-6006","541-514-1332",$row['description']); ?> </p>                                   
                                </div>
								
								<div class="single_comments">
								<!--<p>Street : <?php echo $row['street']; ?></p>
								<p>City :<?php echo $row['city']; ?></p>
								<p>State :<?php echo $row['state']; ?></p>
								<p>Zip :<?php echo $row['zip']; ?></p>-->
								<p>Email : sales@eugenervs.com<?php //echo $row['email']; ?></p>
								<p>Phone : 541-514-1332<?php // echo $row['salesphone']; ?></p>
								<!--<p>WebURL : <?php // echo $row['websiteurl']; ?></p>-->
								
								<p>&nbsp;</p>
								<p> <a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='block';document.getElementById('fade').style.display='block'">Contact Us</a></p>
		<div id="light" class="white_content">
		 <form name="" id="" action="contactus.php" method="post" enctype="multipart/form-data">
		 <table align="center">
		 <tr><td colspan="2"><div style="text-align:center;">  Email : sales@eugenervs.com &nbsp;&nbsp;
                        Phone : <a href="tel:+5415141332">541-514-1332 </a> <br/></div>
					</div></td></tr>
					<tr><td>&nbsp;</td></tr>
		 <tr><td>Name *</td><td><input type="text" name="name" id="name" ></td></tr>
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>Email Id *</td><td><input type="text" name="email" id="email" size="40"></td></tr>
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>Phone No. </td><td><input type="text" name="phoneno" id="phoneno" size="40"></td></tr> 
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>Comments </td><td><textarea name="comment" id="comment" cols="38"></textarea></td></tr>
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
		 <tr><td colspan="2"><input type="submit" name="submit" id="submit" value="Submit"></td><td></td></tr>
		 
		 </table>
		</form>
		
		 <a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'">Close</a></div>
		<div id="fade" class="black_overlay"></div>
		
								<div>
								
								
                            </div>
                        </div>                     
                    </div><!--/.recent comments-->
                       				
                  
    			</aside>  
            </div><!--/.row-->
        </div>
		<?php } } ?>		
    </section>

    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2013 <a target="_blank" href="http://eugene.com/" title="Free Twitter Bootstrap WordPress Themes and HTML templates">Eugene Rvs</a>. All Rights Reserved.
                </div>
                <div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Faq</a></li>
                        <li><a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='block';document.getElementById('fade').style.display='block'">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->
    
	 <script type="text/javascript">
        $(document).ready(function(){
            $('#lightgallery').lightGallery();
        });
        </script>
        <script src="https://cdn.jsdelivr.net/picturefill/2.3.1/picturefill.min.js"></script>
        <script src="dist/js/lightgallery.js"></script>
        <script src="dist/js/lg-fullscreen.js"></script>
        <script src="dist/js/lg-thumbnail.js"></script>
        <script src="dist/js/lg-video.js"></script>
        <script src="dist/js/lg-autoplay.js"></script>
        <script src="dist/js/lg-zoom.js"></script>
        <script src="dist/js/lg-hash.js"></script>
        <script src="dist/js/lg-pager.js"></script>
        <script src="lib/jquery.mousewheel.min.js"></script>	
	
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
	
</body>
</html>