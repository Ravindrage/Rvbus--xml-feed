<?php include "connection.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="www.eugenervs.com">
    <meta name="author" content="">
    <title><?php echo $_REQUEST['class']; ?> Category | EUGENE RV</title>
	
	<link rel="stylesheet" href="css/animations.css" type="text/css">	
	<link href='http://fonts.googleapis.com/css?family=Lato&subset=latin,latin-ext' rel='stylesheet' type='text/css'>			
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		
	<script type="text/javascript">
	var jQuery_1_1_3 = $.noConflict(true);
	</script>
	
	<script src='js/css3-animate-it.js'></script>	
			
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
	<script src="js/slippry.min.js"></script>
	<link rel="stylesheet" href="css/slippry.css">
	<script src="//use.edgefonts.net/cabin;source-sans-pro:n2,i2,n3,n4,n6,n7,n9.js"></script>
		
		
	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body class="homepage">
	    <header id="header" >
        <div class="top-bar" style="background-color:#CCCCCC;" >
            <div class="container" >
                <div class="row" >
                    <div class="col-sm-6 col-xs-4">
                        <div class="top-number title1">Road, Glasgow D04 89GR</div>
                    </div>
                    <div class="col-sm-6 col-xs-8">
                       <div class="social">
                            <ul class="social-share title2">
                              Call us: (800) 2345-6789
                            </ul>
                            </div>
                    </div>
                </div>
            </div><!--/.container-->
        </div><!--/.top-bar-->

        <nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header" style="background-color:#f50606; padding:25px 6px; margin-top:5px;">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">EUGENE RV <!--<img src="images/logo.png" alt="logo">--></a>
                </div>
				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
					  
					  <?php   
					        $sql = "SELECT * FROM tbl_xmldata GROUP BY class limit 7";
                             $result = $conn->query($sql);
					  
					  
							if ($result->num_rows > 0) {							
							$incre_num = 1;
							while($row = $result->fetch_assoc()) {
														
							if($incre_num==1)
							{
							$first = '<li style="text-align:center;"><a href="category.php?class='.$row['class'].'">'.$row['class'].'
							<p><img src="images/menu/'.$incre_num.'.png" style="height:60px; width:105px; border-radius:10px;"/></p></a> 
		<!--<p style="height:10px;color:#fff;margin-top:-15px;"><a href="category.php?class='.$row['class'].'&used=1" style="font-size:10px; padding:0px;margin-top:-5px;color:#fff;">New</a></p>
	<p style="height:10px;color:#fff;margin-top:-10px;"><a href="category.php?class='.$row['class'].'&used=0" style="font-size:10px; padding:0px; margin-top:-5px;color:#fff;">Used</a></p>--></li>';         $incre_num++;
	                         }
							 else
							 {
							 echo '<li style="text-align:center;"><a href="category.php?class='.$row['class'].'">'.$row['class'].'
							<p><img src="images/menu/'.$incre_num.'.png" style="height:60px; width:105px; border-radius:10px;"/></p></a> 
		<!--<p style="height:10px;color:#fff;margin-top:-15px;"><a href="category.php?class='.$row['class'].'&used=1" style="font-size:10px; padding:0px;margin-top:-5px;color:#fff;">New</a></p>
	<p style="height:10px;color:#fff;margin-top:-10px;"><a href="category.php?class='.$row['class'].'&used=0" style="font-size:10px; padding:0px; margin-top:-5px;color:#fff;">Used</a></p>--></li>';         $incre_num++;
							}
							
							if($incre_num==5){	echo $first; }
	
	
							}
							} else {
							echo "0 results";
							}
					   ?>
                       
                       
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
		
    </header><!--/header-->
	
	<section id="portfolio">
        <div class="container">
            <div class="center">
               <h2>All <?php echo $_REQUEST['class']; ?> Rv</h2>
              <p class="lead">
			  Mouse over the images to get details & prices. <br>  Click the "Details Link" to see more images and contact <br>  info</p>
            </div>
        

           <!-- <ul class="portfolio-filte1r text-center" style="list-style:outside none none;">
                <li><a class="btn btn-default active" href="category.php?class=<?php echo $_REQUEST['class']; ?>&used=1">New</a><p></p></li>
                <li><a class="btn btn-default" href="category.php?class=<?php echo $_REQUEST['class']; ?>&used=0" >Used</a></li>
            </ul>--><!--/#portfolio-filter-->

            <div class="row">
                <div class="portfolio-items">
				
					<?php
					if(isset($_REQUEST['class']) and !empty($_REQUEST['class']))
					{
					 $sql = "SELECT * FROM tbl_xmldata where class = '".$_REQUEST['class']."'";
					
					}
					
					if(isset($_REQUEST['class']) and !empty($_REQUEST['class']) and isset($_REQUEST['used']) and !empty($_REQUEST['used']) )
					{
				     $sql = "SELECT * FROM tbl_xmldata where class = '".$_REQUEST['class']."' and neworused = '".$_REQUEST['used']."' ";
					
					}
					 $sql;
					$result = $conn->query($sql);
					
					//echo '<br><br><br>'; exit;
     				
					if ($result->num_rows > 0) {
							while($row = $result->fetch_assoc()) {  ?>
                    <div class="portfolio-item apps col-xs-12 col-sm-4 col-md-3">
                        <div class="recent-work-wrap">
						
						<?php if($row['Photo1']=="")
						 {   $photo = $photo;   }else { $photo = $row['Photo1'];}  ?>
						 
                            <img class="img-responsive" src="<?php echo $photo; ?>" alt="">
                            <div class="overlay">
                                <div class="recent-work-inner">
                                    <h3><a href="#" style="font-size:22px;"><?php echo $row['brand'] ; echo ' ' ;echo $row['model'];  ?></a></h3>
                                    <p>Price : $<?php echo $row['price1'] ;  ?>  </p>
									<p>Fuel Type : <?php echo $row['fueltype'] ;  ?>  </p>
									
                                    <a class="preview" href="product.php?autoid=<?php echo $row['autoid']; ?>" ><i class="fa fa-eye"></i> Details </a>
                                </div> 
                            </div>
                        </div>
                    </div><!--/.portfolio-item-->
					<?php } } ?>
                                    
                </div>
            </div>
        </div>
    </section>
	
	<div id="light" class="white_content">
		 <form name="" id="" action="contactus.php" method="post" enctype="multipart/form-data">
		 <table align="center">
		<tr><td colspan="2"><div style="text-align:center;">  Email : sales@eugenervs.com &nbsp;&nbsp;
                        Phone : <a href="tel:+5415141332">541-514-1332 </a> <br/></div>
					</div></td></tr>
					<tr><td>&nbsp;</td></tr>
		 <tr><td>Name *</td><td><input type="text" name="name" id="name" ></td></tr>
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>Email Id *</td><td><input type="text" name="email" id="email" size="40"></td></tr>
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>Phone No. </td><td><input type="text" name="phoneno" id="phoneno" size="40"></td></tr> 
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>Comments </td><td><textarea name="comment" id="comment" cols="38"></textarea></td></tr>
		 <tr><td>&nbsp;</td></tr>
		 <tr><td>&nbsp;</td><td>&nbsp;</td></tr>
		 <tr><td colspan="2"><input type="submit" name="submit" id="submit" value="Submit"></td><td></td></tr>
		 
		 </table>
		</form>
		
		 <a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='none';document.getElementById('fade').style.display='none'">Close</a></div>
		<div id="fade" class="black_overlay"></div>
		

    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2013 <a target="_blank" href="http://eugene.com/" title="Free Twitter Bootstrap WordPress Themes and HTML templates">Eugene Rvs</a>. All Rights Reserved.
                </div>
                <div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Faq</a></li>
                        <li><a href = "javascript:void(0)" onclick = "document.getElementById('light').style.display='block';document.getElementById('fade').style.display='block'">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->

    <script>  ;(function($){
        // your code
		var demo1 = $("#demo1").slippry({
					// transition: 'fade',
					// useCSS: true,
					// speed: 1000,
					// pause: 3000,
					// auto: true,
					// preload: 'visible',
					// autoHover: false
				});
            })(jQuery);
			
		</script>
		
	<script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
	
</body>
</html>