<?php 



//$con = mysql_connect("mysql5.000webhost.com","a8139674_ravin","ravindra098");



include "connection.php"; 



/*if (!$con)

{ die('Could not connect: ' . mysql_error()); }

mysql_select_db("a8139674_ravin", $con);*/



//echo '<pre>';

//print_r($conn);

	
				//invalid xml file
				
				$lastarray = xml2array("http://www.rvcorral.com/rvt_feed/");
				
				echo '<pre>';
				print_r($lastarray);
				
				
				foreach ($values as $key => $value)
				{  
				//   print_r($value);
				  $object->$key = $value;
				  //echo $object->$key;
				}

			
				 
$sql= "select date from  tbl_xmldata limit 1";
$result = $conn->query($sql);

if ($result->num_rows > 0) {

while($row = $result->fetch_assoc()) {

		$cirrentdate =  date("Y-m-d");

		if($row['date']!=$cirrentdate){

		        file_put_contents("rvtfeed.xml", fopen("http://www.rvcorral.com/rvt_feed/", 'r'));	
				
				$file = 'rvtfeed.xml';
				$current = file_get_contents($file);
				$current .= "</Class></Listing><Inventory>";
				file_put_contents($file, $current);	
				
				
			    @$xml=simplexml_load_file("http://www.rvcorral.com/rvt_feed/"); //or die("Error: Cannot create object");
			   	@$xml=simplexml_load_file("rvtfeed.xml") ;//or die("Error: Cannot create object");

				$aa = "";  $field="";

				if(isset($xml) and !empty($xml))

				{
				foreach($xml->children() as $child)
				{
				foreach($child->children() as $childs)
				{
				$aa .= "'".$childs ."',";
				$field.="".$childs->getname().",";
				}

				$field.="date,";

				$aa .= "'".$cirrentdate."',";

				

				$aa = substr_replace($aa, "", -1);

				$field= substr_replace($field, "", -1);

				

				$sql = "INSERT into tbl_xmldata ($field) values ( $aa )";

				$aa = "";

				$field="";

				//$rr = mysql_query($sql);

				$rr = $conn->query($sql); 

				

				} 

				 }

				if (isset($rr) and !empty($rr)){

				           // echo "data successfully captured from XML and inserted in db";

				            //$sql1 = "TRUNCATE TABLE tbl_xmldata";

							$sql2 = "Delete FROM tbl_xmldata WHERE date < CURDATE()";

			                $result1 = $conn->query($sql1);

				}else{ //echo "sorry no data insertion";

				}



		}

}}














function xml2array($url, $get_attributes = 1, $priority = 'tag')
{
    $contents = "";
    if (!function_exists('xml_parser_create'))
    {
        return array ();
    }
    $parser = xml_parser_create('');
    if (!($fp = @ fopen($url, 'rb')))
    {
        return array ();
    }
    while (!feof($fp))
    {
        $contents .= fread($fp, 548192);
    }
    fclose($fp);
    xml_parser_set_option($parser, XML_OPTION_TARGET_ENCODING, "UTF-8");
    xml_parser_set_option($parser, XML_OPTION_CASE_FOLDING, 0);
    xml_parser_set_option($parser, XML_OPTION_SKIP_WHITE, 1);
    xml_parse_into_struct($parser, trim($contents), $xml_values);
    xml_parser_free($parser);
    if (!$xml_values)
        return; //Hmm...
    $xml_array = array ();
    $parents = array ();
    $opened_tags = array ();
    $arr = array ();
    $current = & $xml_array;
    $repeated_tag_index = array ();
    foreach ($xml_values as $data)
    {
        unset ($attributes, $value);
        extract($data);
        $result = array ();
        $attributes_data = array ();
        if (isset ($value))
        {
            if ($priority == 'tag')
                $result = $value;
            else
                $result['value'] = $value;
        }
        if (isset ($attributes) and $get_attributes)
        {
            foreach ($attributes as $attr => $val)
            {
                if ($priority == 'tag')
                    $attributes_data[$attr] = $val;
                else
                    $result['attr'][$attr] = $val; //Set all the attributes in a array called 'attr'
            }
        }
        if ($type == "open")
        {
            $parent[$level -1] = & $current;
            if (!is_array($current) or (!in_array($tag, array_keys($current))))
            {
                $current[$tag] = $result;
                if ($attributes_data)
                    $current[$tag . '_attr'] = $attributes_data;
                $repeated_tag_index[$tag . '_' . $level] = 1;
                $current = & $current[$tag];
            }
            else
            {
                if (isset ($current[$tag][0]))
                {
                    $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                    $repeated_tag_index[$tag . '_' . $level]++;
                }
                else
                {
                    $current[$tag] = array (
                        $current[$tag],
                        $result
                    );
                    $repeated_tag_index[$tag . '_' . $level] = 2;
                    if (isset ($current[$tag . '_attr']))
                    {
                        $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                        unset ($current[$tag . '_attr']);
                    }
                }
                $last_item_index = $repeated_tag_index[$tag . '_' . $level] - 1;
                $current = & $current[$tag][$last_item_index];
            }
        }
        elseif ($type == "complete")
        {
            if (!isset ($current[$tag]))
            {
                $current[$tag] = $result;
                $repeated_tag_index[$tag . '_' . $level] = 1;
                if ($priority == 'tag' and $attributes_data)
                    $current[$tag . '_attr'] = $attributes_data;
            }
            else
            {
                if (isset ($current[$tag][0]) and is_array($current[$tag]))
                {
                    $current[$tag][$repeated_tag_index[$tag . '_' . $level]] = $result;
                    if ($priority == 'tag' and $get_attributes and $attributes_data)
                    {
                        $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                    }
                    $repeated_tag_index[$tag . '_' . $level]++;
                }
                else
                {
                    $current[$tag] = array (
                        $current[$tag],
                        $result
                    );
                    $repeated_tag_index[$tag . '_' . $level] = 1;
                    if ($priority == 'tag' and $get_attributes)
                    {
                        if (isset ($current[$tag . '_attr']))
                        {
                            $current[$tag]['0_attr'] = $current[$tag . '_attr'];
                            unset ($current[$tag . '_attr']);
                        }
                        if ($attributes_data)
                        {
                            $current[$tag][$repeated_tag_index[$tag . '_' . $level] . '_attr'] = $attributes_data;
                        }
                    }
                    $repeated_tag_index[$tag . '_' . $level]++; //0 and 1 index is already taken
                }
            }
        }
        elseif ($type == 'close')
        {
            $current = & $parent[$level -1];
        }
    }
    return ($xml_array);
}
?>


