<?php include "connection.php"; ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="www.eugenervs.com">
    <meta name="author" content="">
    <title>Contact Us | EUGENE RV</title>
	
	<link rel="stylesheet" href="css/animations.css" type="text/css">	
	<link href='http://fonts.googleapis.com/css?family=Lato&subset=latin,latin-ext' rel='stylesheet' type='text/css'>			
	<script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.1/jquery.min.js"></script>
		
	<script type="text/javascript">
	var jQuery_1_1_3 = $.noConflict(true);
	</script>
	
	<script src='js/css3-animate-it.js'></script>	
			
	<script src="http://ajax.googleapis.com/ajax/libs/jquery/2.0.0/jquery.min.js"></script>
	<script src="js/slippry.min.js"></script>
	<link rel="stylesheet" href="css/slippry.css">
	<script src="//use.edgefonts.net/cabin;source-sans-pro:n2,i2,n3,n4,n6,n7,n9.js"></script>
		
		
	<!-- core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <link href="css/font-awesome.min.css" rel="stylesheet">
    <link href="css/animate.min.css" rel="stylesheet">
    <link href="css/prettyPhoto.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
    <link href="css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body class="homepage">
	    <header id="header" >
        <div class="top-bar" style="background-color:#CCCCCC;" >
            <div class="container" >
                <div class="row" >
                    <div class="col-sm-6 col-xs-4">
                        <div class="top-number title1">Road, Glasgow D04 89GR</div>
                    </div>
                    <div class="col-sm-6 col-xs-8">
                       <div class="social">
                            <ul class="social-share title2">
                              Call us: (800) 2345-6789
                            </ul>
                            </div>
                    </div>
                </div>
            </div><!--/.container-->
        </div><!--/.top-bar-->

        <nav class="navbar navbar-inverse" role="banner">
            <div class="container">
                <div class="navbar-header" style="background-color:#f50606; padding:25px 6px; margin-top:5px;">
                    <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">EUGENE RV <!--<img src="images/logo.png" alt="logo">--></a>
                </div>
				
                <div class="collapse navbar-collapse navbar-right">
                    <ul class="nav navbar-nav">
					  
					<?php    $sql = "SELECT * FROM tbl_xmldata GROUP BY class limit 7";
                             $result = $conn->query($sql);
							if ($result->num_rows > 0) {							
							$incre_num = 1;
							while($row = $result->fetch_assoc()) {
														
							if($incre_num==1)
							{
							$first = '<li style="text-align:center;"><a href="category.php?class='.$row['class'].'">'.$row['class'].'
							<p><img src="images/menu/'.$incre_num.'.png" style="height:60px; width:105px; border-radius:10px;"/></p></a> 
		<!--<p style="height:10px;color:#fff;margin-top:-15px;"><a href="category.php?class='.$row['class'].'&used=1" style="font-size:10px; padding:0px;margin-top:-5px;color:#fff;">New</a></p>
	<p style="height:10px;color:#fff;margin-top:-10px;"><a href="category.php?class='.$row['class'].'&used=0" style="font-size:10px; padding:0px; margin-top:-5px;color:#fff;">Used</a></p>--></li>';         $incre_num++;
	                         }
							 else
							 {
							 echo '<li style="text-align:center;"><a href="category.php?class='.$row['class'].'">'.$row['class'].'
							<p><img src="images/menu/'.$incre_num.'.png" style="height:60px; width:105px; border-radius:10px;"/></p></a> 
		<!--<p style="height:10px;color:#fff;margin-top:-15px;"><a href="category.php?class='.$row['class'].'&used=1" style="font-size:10px; padding:0px;margin-top:-5px;color:#fff;">New</a></p>
	<p style="height:10px;color:#fff;margin-top:-10px;"><a href="category.php?class='.$row['class'].'&used=0" style="font-size:10px; padding:0px; margin-top:-5px;color:#fff;">Used</a></p>--></li>';         $incre_num++;
							}
							
							if($incre_num==5){	echo $first; }
	
	
							}
							} else {
							echo "0 results";
							}
					   ?>
                       
                       
                    </ul>
                </div>
            </div><!--/.container-->
        </nav><!--/nav-->
		
    </header><!--/header-->
	
	<section id="portfolio">
        <div class="container">
            <div class="center">
               <h2>Thank You </h2>
              <p class="lead" style="height:300px;">Thank you for Contact US </p>
            </div>
        

            <?php 
             
			if(isset($_POST['submit']) and !empty($_POST['submit']))
			{
			 
			if( !isset($_POST['name']) and empty($_POST['name'])){ $name = ''; } else { $name=$_POST['name']; }
			if( !isset($_POST['email']) and empty($_POST['email'])){ $email = ''; } else { $email=$_POST['email']; }
			if( !isset($_POST['address']) and empty($_POST['address'])){   $address = '' ;  }else{ $address=$_POST['address'];   }
			if( !isset($_POST['phoneno']) and empty($_POST['phoneno'])){   $phoneno = '';   }else{ $phoneno=$_POST['phoneno'];   }
			if( !isset($_POST['comments']) and empty($_POST['comments'])){ $comments = '';  }else{ $comments=$_POST['comments']; }
			
			$admin_email = "sales@eugenervs.com";
			//$email = $_REQUEST['email'];
			$subject = 'Concact Us';
			$comment = 'Hello I am '.$name.'address :'.$address.'phone No'.$phoneno.'Comments'.$comments;
			
			mail($admin_email, "$subject", $comment, "From:" . $email);
			

			}
			
			?>
        </div>
    </section>

    <footer id="footer" class="midnight-blue">
        <div class="container">
            <div class="row">
                <div class="col-sm-6">
                    &copy; 2013 <a target="_blank" href="http://eugene.com/" title="Free Twitter Bootstrap WordPress Themes and HTML templates">Eugene Rvs</a>. All Rights Reserved.
                </div>
                <div class="col-sm-6">
                    <ul class="pull-right">
                        <li><a href="index.php">Home</a></li>
                        <li><a href="#">About Us</a></li>
                        <li><a href="#">Faq</a></li>
                        <li><a href="#">Contact Us</a></li>
                    </ul>
                </div>
            </div>
        </div>
    </footer><!--/#footer-->  
		
	<script src="js/jquery.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.prettyPhoto.js"></script>
    <script src="js/jquery.isotope.min.js"></script>
    <script src="js/main.js"></script>
    <script src="js/wow.min.js"></script>
	
</body>
</html>